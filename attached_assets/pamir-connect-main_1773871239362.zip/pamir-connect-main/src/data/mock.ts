import type { UserProfile, Post, Group, Event, ChatThread } from "@/types";

const avatars = [
  "https://api.dicebear.com/7.x/avataaars/svg?seed=Ali",
  "https://api.dicebear.com/7.x/avataaars/svg?seed=Fatima",
  "https://api.dicebear.com/7.x/avataaars/svg?seed=Karim",
  "https://api.dicebear.com/7.x/avataaars/svg?seed=Zarina",
  "https://api.dicebear.com/7.x/avataaars/svg?seed=Rustam",
];

export const users: UserProfile[] = [
  { id: "1", name: "Али Мамадшоев", avatar: avatars[0], institution: "ХГУИТ", city: "Мургаб", bio: "Студент IT. Люблю горы и код.", badge: "leader", rating: 520 },
  { id: "2", name: "Фатима Курбанова", avatar: avatars[1], institution: "ТНУ", city: "Хорог", bio: "Изучаю медицину. Волонтёр.", badge: "active", rating: 380 },
  { id: "3", name: "Карим Шодиев", avatar: avatars[2], institution: "ХГУИТ", city: "Ишкашим", bio: "Футбол, музыка, программирование.", rating: 290 },
  { id: "4", name: "Зарина Акбарова", avatar: avatars[3], institution: "ТНУ", city: "Мургаб", bio: "Будущий учитель. Пишу стихи.", badge: "active", rating: 350 },
  { id: "5", name: "Рустам Назаров", avatar: avatars[4], institution: "КТУТ", city: "Хорог", bio: "Инженер в душе.", rating: 200 },
];

export const posts: Post[] = [
  {
    id: "p1", author: users[0], content: "Кто-нибудь идёт на хакатон в Хороге на следующей неделе? Давайте соберём команду от Сарыкола! 🚀",
    likes: 24, liked: false, comments: [
      { id: "c1", author: users[1], text: "Я иду! Давай команду собирать 🙌", createdAt: "2 ч назад" },
      { id: "c2", author: users[2], text: "Тоже хочу! Запишите меня", createdAt: "1 ч назад" },
    ], createdAt: "3 ч назад",
  },
  {
    id: "p2", author: users[1], content: "Сегодня провели медицинский осмотр для школьников в Мургабе. Спасибо всем волонтёрам! ❤️",
    image: "https://images.unsplash.com/photo-1584515933487-779824d29309?w=600&h=400&fit=crop",
    likes: 47, liked: true, comments: [
      { id: "c3", author: users[3], text: "Молодцы! Горжусь нашим сообществом", createdAt: "5 ч назад" },
    ], createdAt: "6 ч назад",
  },
  {
    id: "p3", author: users[2], content: "Новый трек готов! Записал кавер на памирскую народную песню в современной обработке 🎵",
    likes: 31, liked: false, comments: [], createdAt: "8 ч назад",
  },
  {
    id: "p4", author: users[3], content: "Осень в горах Памира — это что-то невероятное. Делюсь фото с сегодняшней прогулки 🏔️",
    image: "https://images.unsplash.com/photo-1506905925346-21bda4d32df4?w=600&h=400&fit=crop",
    likes: 63, liked: false, comments: [
      { id: "c4", author: users[4], text: "Красотища! Где это снято?", createdAt: "10 ч назад" },
    ], createdAt: "12 ч назад",
  },
];

export const groups: Group[] = [
  { id: "g1", name: "IT Сарыкол", description: "Программирование, технологии и стартапы", memberCount: 128, cover: "https://images.unsplash.com/photo-1517694712202-14dd9538aa97?w=400&h=200&fit=crop", joined: true },
  { id: "g2", name: "Спорт и Здоровье", description: "Футбол, волейбол, походы в горы", memberCount: 95, cover: "https://images.unsplash.com/photo-1461896836934-bd45ba8fcfdd?w=400&h=200&fit=crop", joined: false },
  { id: "g3", name: "Музыка Памира", description: "Традиционная и современная музыка", memberCount: 73, cover: "https://images.unsplash.com/photo-1511379938547-c1f69419868d?w=400&h=200&fit=crop", joined: true },
  { id: "g4", name: "Волонтёры Мургаба", description: "Помогаем сообществу вместе", memberCount: 56, cover: "https://images.unsplash.com/photo-1559027615-cd4628902d4a?w=400&h=200&fit=crop", joined: false },
  { id: "g5", name: "Наука и Образование", description: "Подготовка к экзаменам, учебные материалы", memberCount: 110, cover: "https://images.unsplash.com/photo-1532012197267-da84d127e765?w=400&h=200&fit=crop", joined: false },
];

export const events: Event[] = [
  { id: "e1", title: "Хакатон Хорог 2026", description: "48-часовой хакатон для студентов Памира", date: "25 марта 2026", location: "Хорог, ХГУИТ", participantCount: 42, participating: false, cover: "https://images.unsplash.com/photo-1504384308090-c894fdcc538d?w=400&h=200&fit=crop" },
  { id: "e2", title: "Наурӯз-fest", description: "Празднование Навруза с музыкой и едой", date: "21 марта 2026", location: "Мургаб, Центр", participantCount: 156, participating: true, cover: "https://images.unsplash.com/photo-1533174072545-7a4b6ad7a6c3?w=400&h=200&fit=crop" },
  { id: "e3", title: "Поход на озеро Зоркуль", description: "Однодневный поход с фотосессией", date: "5 апреля 2026", location: "Мургаб", participantCount: 28, participating: false, cover: "https://images.unsplash.com/photo-1464822759023-fed622ff2c3b?w=400&h=200&fit=crop" },
];

export const chatThreads: ChatThread[] = [
  { id: "ch1", user: users[1], lastMessage: "Да, завтра в 10 утра встречаемся!", lastMessageTime: "14:30", unread: 2 },
  { id: "ch2", user: users[2], lastMessage: "Послушай трек, отправил ссылку", lastMessageTime: "12:15", unread: 0 },
  { id: "ch3", user: users[3], lastMessage: "Спасибо за помощь с проектом 🙏", lastMessageTime: "Вчера", unread: 1 },
  { id: "ch4", user: users[4], lastMessage: "Привет! Как дела?", lastMessageTime: "Вчера", unread: 0 },
];

export const currentUser = users[0];
