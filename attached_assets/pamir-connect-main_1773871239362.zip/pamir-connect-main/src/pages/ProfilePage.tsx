import { currentUser, users } from "@/data/mock";
import UserBadge from "@/components/UserBadge";
import { Settings, Trophy, Star } from "lucide-react";

const ProfilePage = () => {
  const topUsers = [...users].sort((a, b) => b.rating - a.rating);

  return (
    <div className="mx-auto max-w-lg">
      <header className="sticky top-0 z-40 border-b border-border bg-card px-4 py-3">
        <div className="flex items-center justify-between">
          <h1 className="font-display text-xl font-bold text-foreground">Профиль</h1>
          <button className="text-muted-foreground">
            <Settings className="h-5 w-5" />
          </button>
        </div>
      </header>

      <div className="p-4 space-y-6">
        {/* Profile card */}
        <div className="rounded-lg border border-border bg-card p-6 text-center">
          <img src={currentUser.avatar} alt={currentUser.name} className="mx-auto h-20 w-20 rounded-full bg-muted" />
          <div className="mt-3 flex items-center justify-center gap-2">
            <h2 className="font-display text-lg font-bold text-card-foreground">{currentUser.name}</h2>
            {currentUser.badge && <UserBadge type={currentUser.badge} />}
          </div>
          <p className="text-sm text-muted-foreground mt-1">{currentUser.institution} • {currentUser.city}</p>
          <p className="text-sm text-muted-foreground mt-2">{currentUser.bio}</p>
          <div className="mt-4 flex items-center justify-center gap-2 text-accent">
            <Trophy className="h-4 w-4" />
            <span className="font-display font-bold text-sm">{currentUser.rating} очков</span>
          </div>
          <button className="mt-4 w-full rounded-lg bg-secondary py-2 text-sm font-semibold text-secondary-foreground">
            Редактировать
          </button>
        </div>

        {/* Top users */}
        <section>
          <h2 className="font-display font-semibold text-sm text-foreground mb-3 flex items-center gap-2">
            <Star className="h-4 w-4 text-accent" />
            Топ активных
          </h2>
          <div className="space-y-2">
            {topUsers.map((user, i) => (
              <div key={user.id} className="flex items-center gap-3 rounded-lg border border-border bg-card p-3">
                <span className={`flex h-7 w-7 items-center justify-center rounded-full text-xs font-bold ${
                  i === 0 ? "bg-accent text-accent-foreground" : i === 1 ? "bg-muted text-muted-foreground" : "bg-secondary text-secondary-foreground"
                }`}>
                  {i + 1}
                </span>
                <img src={user.avatar} alt={user.name} className="h-9 w-9 rounded-full bg-muted" />
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2">
                    <span className="font-display font-semibold text-sm text-card-foreground truncate">{user.name}</span>
                    {user.badge && <UserBadge type={user.badge} />}
                  </div>
                  <span className="text-xs text-muted-foreground">{user.institution}</span>
                </div>
                <span className="font-display font-bold text-sm text-accent">{user.rating}</span>
              </div>
            ))}
          </div>
        </section>
      </div>
    </div>
  );
};

export default ProfilePage;
