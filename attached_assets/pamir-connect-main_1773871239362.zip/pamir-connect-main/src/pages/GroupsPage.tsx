import { useState } from "react";
import { motion } from "framer-motion";
import { Search, Plus } from "lucide-react";
import { groups as mockGroups } from "@/data/mock";

const GroupsPage = () => {
  const [groups, setGroups] = useState(mockGroups);
  const [search, setSearch] = useState("");

  const filtered = groups.filter((g) =>
    g.name.toLowerCase().includes(search.toLowerCase())
  );

  const toggleJoin = (id: string) => {
    setGroups(groups.map((g) =>
      g.id === id ? { ...g, joined: !g.joined, memberCount: g.joined ? g.memberCount - 1 : g.memberCount + 1 } : g
    ));
  };

  return (
    <div className="mx-auto max-w-lg">
      <header className="sticky top-0 z-40 border-b border-border bg-card px-4 py-3">
        <div className="flex items-center justify-between mb-3">
          <h1 className="font-display text-xl font-bold text-foreground">Группы</h1>
          <button className="rounded-full bg-primary p-2 text-primary-foreground">
            <Plus className="h-4 w-4" />
          </button>
        </div>
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <input
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Поиск групп..."
            className="w-full rounded-lg bg-secondary py-2 pl-9 pr-4 text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary"
          />
        </div>
      </header>

      <div className="p-4 space-y-3">
        {filtered.map((group) => (
          <div key={group.id} className="rounded-lg border border-border bg-card overflow-hidden">
            <img src={group.cover} alt={group.name} className="h-28 w-full object-cover bg-muted" loading="lazy" />
            <div className="p-3">
              <h3 className="font-display font-semibold text-sm text-card-foreground">{group.name}</h3>
              <p className="text-xs text-muted-foreground mt-0.5">{group.description}</p>
              <div className="mt-3 flex items-center justify-between">
                <span className="text-xs text-muted-foreground">{group.memberCount} участников</span>
                <motion.button
                  whileTap={{ scale: 1.05 }}
                  onClick={() => toggleJoin(group.id)}
                  className={`rounded-lg px-4 py-1.5 text-xs font-semibold transition-colors ${
                    group.joined
                      ? "bg-secondary text-secondary-foreground"
                      : "bg-primary text-primary-foreground"
                  }`}
                >
                  {group.joined ? "Вы в группе" : "Вступить"}
                </motion.button>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default GroupsPage;
