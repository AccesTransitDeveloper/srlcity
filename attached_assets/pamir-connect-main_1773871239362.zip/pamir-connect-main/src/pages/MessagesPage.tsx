import { chatThreads } from "@/data/mock";
import { Search } from "lucide-react";

const MessagesPage = () => {
  return (
    <div className="mx-auto max-w-lg">
      <header className="sticky top-0 z-40 border-b border-border bg-card px-4 py-3">
        <h1 className="font-display text-xl font-bold text-foreground mb-3">Сообщения</h1>
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <input
            placeholder="Поиск..."
            className="w-full rounded-lg bg-secondary py-2 pl-9 pr-4 text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary"
          />
        </div>
      </header>

      <div className="divide-y divide-border">
        {chatThreads.map((thread) => (
          <button key={thread.id} className="flex w-full items-center gap-3 px-4 py-3 text-left hover:bg-secondary/50 transition-colors">
            <div className="relative">
              <img src={thread.user.avatar} alt={thread.user.name} className="h-12 w-12 rounded-full bg-muted" />
              {thread.unread > 0 && (
                <span className="absolute -right-0.5 -top-0.5 flex h-5 w-5 items-center justify-center rounded-full bg-primary text-[10px] font-bold text-primary-foreground">
                  {thread.unread}
                </span>
              )}
            </div>
            <div className="flex-1 min-w-0">
              <div className="flex items-center justify-between">
                <span className="font-display font-semibold text-sm text-foreground truncate">{thread.user.name}</span>
                <span className="text-xs text-muted-foreground whitespace-nowrap ml-2">{thread.lastMessageTime}</span>
              </div>
              <p className={`text-xs truncate mt-0.5 ${thread.unread > 0 ? "text-foreground font-medium" : "text-muted-foreground"}`}>
                {thread.lastMessage}
              </p>
            </div>
          </button>
        ))}
      </div>
    </div>
  );
};

export default MessagesPage;
