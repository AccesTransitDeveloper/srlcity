import { useState } from "react";
import { motion } from "framer-motion";
import { Plus, CalendarDays, MapPin, Users } from "lucide-react";
import { events as mockEvents } from "@/data/mock";

const EventsPage = () => {
  const [events, setEvents] = useState(mockEvents);

  const toggleParticipation = (id: string) => {
    setEvents(events.map((e) =>
      e.id === id
        ? { ...e, participating: !e.participating, participantCount: e.participating ? e.participantCount - 1 : e.participantCount + 1 }
        : e
    ));
  };

  return (
    <div className="mx-auto max-w-lg">
      <header className="sticky top-0 z-40 border-b border-border bg-card px-4 py-3">
        <div className="flex items-center justify-between">
          <h1 className="font-display text-xl font-bold text-foreground">События</h1>
          <button className="rounded-full bg-primary p-2 text-primary-foreground">
            <Plus className="h-4 w-4" />
          </button>
        </div>
      </header>

      <div className="p-4 space-y-4">
        {events.map((event) => (
          <div key={event.id} className="rounded-lg border border-border bg-card overflow-hidden">
            <img src={event.cover} alt={event.title} className="h-40 w-full object-cover bg-muted" loading="lazy" />
            <div className="p-4">
              <h3 className="font-display font-semibold text-base text-card-foreground">{event.title}</h3>
              <p className="text-sm text-muted-foreground mt-1">{event.description}</p>
              <div className="mt-3 space-y-1.5">
                <div className="flex items-center gap-2 text-xs text-muted-foreground">
                  <CalendarDays className="h-3.5 w-3.5" /> {event.date}
                </div>
                <div className="flex items-center gap-2 text-xs text-muted-foreground">
                  <MapPin className="h-3.5 w-3.5" /> {event.location}
                </div>
                <div className="flex items-center gap-2 text-xs text-muted-foreground">
                  <Users className="h-3.5 w-3.5" /> {event.participantCount} участников
                </div>
              </div>
              <motion.button
                whileTap={{ scale: 1.05 }}
                onClick={() => toggleParticipation(event.id)}
                className={`mt-4 w-full rounded-lg py-2.5 text-sm font-semibold transition-colors ${
                  event.participating
                    ? "bg-success text-success-foreground"
                    : "bg-accent text-accent-foreground"
                }`}
              >
                {event.participating ? "✓ Вы участвуете" : "Участвовать"}
              </motion.button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default EventsPage;
