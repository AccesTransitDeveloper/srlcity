import { useState } from "react";
import { Bell } from "lucide-react";
import PostCard from "@/components/PostCard";
import CreatePost from "@/components/CreatePost";
import EventCard from "@/components/EventCard";
import { posts as mockPosts, events, currentUser } from "@/data/mock";
import type { Post } from "@/types";

const FeedPage = () => {
  const [posts, setPosts] = useState<Post[]>(mockPosts);

  const handleNewPost = (content: string) => {
    const newPost: Post = {
      id: `p${Date.now()}`,
      author: currentUser,
      content,
      likes: 0,
      liked: false,
      comments: [],
      createdAt: "Только что",
    };
    setPosts([newPost, ...posts]);
  };

  return (
    <div className="mx-auto max-w-lg">
      {/* Header */}
      <header className="sticky top-0 z-40 border-b border-border bg-card px-4 py-3">
        <div className="flex items-center justify-between">
          <h1 className="font-display text-xl font-bold text-foreground">Sarykol Connect</h1>
          <button className="relative text-muted-foreground">
            <Bell className="h-5 w-5" />
            <span className="absolute -right-1 -top-1 h-4 w-4 rounded-full bg-destructive text-[10px] font-bold text-destructive-foreground flex items-center justify-center">3</span>
          </button>
        </div>
      </header>

      <div className="p-4 space-y-4">
        {/* Events horizontal scroll */}
        <section>
          <h2 className="font-display font-semibold text-sm text-foreground mb-3">Ближайшие события</h2>
          <div className="flex gap-3 overflow-x-auto pb-2 snap-x snap-mandatory scrollbar-hide -mx-4 px-4">
            {events.map((event) => (
              <EventCard key={event.id} event={event} />
            ))}
          </div>
        </section>

        {/* Create post */}
        <CreatePost avatar={currentUser.avatar} onPost={handleNewPost} />

        {/* Posts feed */}
        {posts.map((post) => (
          <PostCard key={post.id} post={post} />
        ))}
      </div>
    </div>
  );
};

export default FeedPage;
