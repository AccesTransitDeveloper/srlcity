import { useState } from "react";
import { Heart, MessageCircle, Send } from "lucide-react";
import { motion } from "framer-motion";
import type { Post } from "@/types";
import UserBadge from "./UserBadge";

interface PostCardProps {
  post: Post;
}

const PostCard = ({ post }: PostCardProps) => {
  const [liked, setLiked] = useState(post.liked);
  const [likesCount, setLikesCount] = useState(post.likes);
  const [showComments, setShowComments] = useState(false);

  const handleLike = () => {
    setLiked(!liked);
    setLikesCount((c) => (liked ? c - 1 : c + 1));
  };

  return (
    <div className="rounded-lg border border-border bg-card p-4">
      {/* Author header */}
      <div className="flex items-center gap-3 mb-3">
        <img src={post.author.avatar} alt={post.author.name} className="h-10 w-10 rounded-full bg-muted" />
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2">
            <span className="font-display font-semibold text-sm text-card-foreground truncate">{post.author.name}</span>
            {post.author.badge && <UserBadge type={post.author.badge} />}
          </div>
          <span className="text-xs text-muted-foreground">{post.createdAt}</span>
        </div>
      </div>

      {/* Content */}
      <p className="text-sm text-card-foreground mb-3 leading-relaxed">{post.content}</p>

      {/* Image */}
      {post.image && (
        <div className="mb-3 overflow-hidden rounded-lg">
          <img src={post.image} alt="" className="w-full h-48 object-cover bg-muted" loading="lazy" />
        </div>
      )}

      {/* Actions */}
      <div className="flex items-center gap-4 pt-2 border-t border-border">
        <motion.button
          whileTap={{ scale: 1.05 }}
          onClick={handleLike}
          className={`flex items-center gap-1.5 text-sm transition-colors ${liked ? "text-destructive" : "text-muted-foreground"}`}
        >
          <Heart className="h-4 w-4" fill={liked ? "currentColor" : "none"} />
          <span>{likesCount}</span>
        </motion.button>

        <button
          onClick={() => setShowComments(!showComments)}
          className="flex items-center gap-1.5 text-sm text-muted-foreground"
        >
          <MessageCircle className="h-4 w-4" />
          <span>{post.comments.length}</span>
        </button>

        <button className="flex items-center gap-1.5 text-sm text-muted-foreground ml-auto">
          <Send className="h-4 w-4" />
        </button>
      </div>

      {/* Comments */}
      {showComments && post.comments.length > 0 && (
        <div className="mt-3 space-y-2 pt-2 border-t border-border">
          {post.comments.map((comment) => (
            <div key={comment.id} className="flex items-start gap-2">
              <img src={comment.author.avatar} alt="" className="h-6 w-6 rounded-full bg-muted mt-0.5" />
              <div>
                <span className="text-xs font-semibold text-card-foreground">{comment.author.name}</span>
                <p className="text-xs text-muted-foreground">{comment.text}</p>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default PostCard;
