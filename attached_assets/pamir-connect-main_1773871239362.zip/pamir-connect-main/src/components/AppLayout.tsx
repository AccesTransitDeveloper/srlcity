import { Outlet, useLocation, useNavigate } from "react-router-dom";
import { Home, Users, CalendarDays, MessageCircle, User } from "lucide-react";

const navItems = [
  { path: "/", icon: Home, label: "Лента" },
  { path: "/groups", icon: Users, label: "Группы" },
  { path: "/events", icon: CalendarDays, label: "События" },
  { path: "/messages", icon: MessageCircle, label: "Чат" },
  { path: "/profile", icon: User, label: "Профиль" },
];

const AppLayout = () => {
  const location = useLocation();
  const navigate = useNavigate();

  return (
    <div className="min-h-screen bg-background pb-20">
      <Outlet />
      <nav className="fixed bottom-0 left-0 right-0 z-50 border-t border-border bg-card">
        <div className="mx-auto flex max-w-lg items-center justify-around py-2">
          {navItems.map(({ path, icon: Icon, label }) => {
            const isActive = location.pathname === path;
            return (
              <button
                key={path}
                onClick={() => navigate(path)}
                className={`flex flex-col items-center gap-0.5 px-3 py-1 text-xs transition-colors ${
                  isActive ? "text-primary" : "text-muted-foreground"
                }`}
              >
                <Icon className="h-5 w-5" strokeWidth={isActive ? 2.5 : 2} />
                <span className="font-medium">{label}</span>
              </button>
            );
          })}
        </div>
      </nav>
    </div>
  );
};

export default AppLayout;
