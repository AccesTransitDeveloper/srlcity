import { useState } from "react";
import { motion } from "framer-motion";
import type { Event } from "@/types";
import { CalendarDays, MapPin, Users } from "lucide-react";

const EventCard = ({ event }: { event: Event }) => {
  const [participating, setParticipating] = useState(event.participating);
  const [count, setCount] = useState(event.participantCount);

  const toggle = () => {
    setParticipating(!participating);
    setCount((c) => (participating ? c - 1 : c + 1));
  };

  return (
    <div className="min-w-[280px] snap-start rounded-lg border border-border bg-card overflow-hidden">
      <img src={event.cover} alt={event.title} className="h-32 w-full object-cover bg-muted" loading="lazy" />
      <div className="p-3">
        <h3 className="font-display font-semibold text-sm text-card-foreground">{event.title}</h3>
        <div className="mt-1.5 flex items-center gap-2 text-xs text-muted-foreground">
          <CalendarDays className="h-3.5 w-3.5" /> {event.date}
        </div>
        <div className="mt-1 flex items-center gap-2 text-xs text-muted-foreground">
          <MapPin className="h-3.5 w-3.5" /> {event.location}
        </div>
        <div className="mt-1 flex items-center gap-2 text-xs text-muted-foreground">
          <Users className="h-3.5 w-3.5" /> {count} участников
        </div>
        <motion.button
          whileTap={{ scale: 1.05 }}
          onClick={toggle}
          className={`mt-3 w-full rounded-lg py-2 text-xs font-semibold transition-colors ${
            participating
              ? "bg-success text-success-foreground"
              : "bg-accent text-accent-foreground"
          }`}
        >
          {participating ? "✓ Участвую" : "Участвовать"}
        </motion.button>
      </div>
    </div>
  );
};

export default EventCard;
