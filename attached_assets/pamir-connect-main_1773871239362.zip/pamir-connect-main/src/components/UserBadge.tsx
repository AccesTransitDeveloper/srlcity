import { Star } from "lucide-react";

interface BadgeProps {
  type: "active" | "leader";
}

const UserBadge = ({ type }: BadgeProps) => {
  if (type === "leader") {
    return (
      <span className="inline-flex items-center gap-0.5 rounded-full bg-accent px-2 py-0.5 text-[10px] font-semibold text-accent-foreground">
        <Star className="h-3 w-3" />
        Лидер
      </span>
    );
  }
  return (
    <span className="inline-flex items-center gap-0.5 rounded-full bg-success px-2 py-0.5 text-[10px] font-semibold text-success-foreground">
      Активный
    </span>
  );
};

export default UserBadge;
