export interface UserProfile {
  id: string;
  name: string;
  avatar: string;
  institution: string;
  city: string;
  bio: string;
  badge?: "active" | "leader";
  rating: number;
}

export interface Post {
  id: string;
  author: UserProfile;
  content: string;
  image?: string;
  likes: number;
  liked: boolean;
  comments: Comment[];
  createdAt: string;
  groupId?: string;
}

export interface Comment {
  id: string;
  author: UserProfile;
  text: string;
  createdAt: string;
}

export interface Group {
  id: string;
  name: string;
  description: string;
  memberCount: number;
  cover: string;
  joined: boolean;
}

export interface Event {
  id: string;
  title: string;
  description: string;
  date: string;
  location: string;
  participantCount: number;
  participating: boolean;
  cover: string;
}

export interface ChatThread {
  id: string;
  user: UserProfile;
  lastMessage: string;
  lastMessageTime: string;
  unread: number;
}

export interface Notification {
  id: string;
  type: "like" | "comment" | "message" | "invite";
  from: UserProfile;
  text: string;
  createdAt: string;
  read: boolean;
}
